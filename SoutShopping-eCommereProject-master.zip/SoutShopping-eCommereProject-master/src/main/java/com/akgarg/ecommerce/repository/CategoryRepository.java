package com.akgarg.ecommerce.repository;

import com.akgarg.ecommerce.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, String> {
    // implementation will be provided by the spring boot
}
