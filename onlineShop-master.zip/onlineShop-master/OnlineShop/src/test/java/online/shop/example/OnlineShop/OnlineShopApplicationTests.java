package online.shop.example.OnlineShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
