package online.shop.example.OnlineShop.user.controller;

import org.springframework.stereotype.Controller;


public class UserController {
}
