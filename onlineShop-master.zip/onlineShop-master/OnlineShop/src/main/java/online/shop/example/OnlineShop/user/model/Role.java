package online.shop.example.OnlineShop.user.model;

public enum Role {
    User, Admin
}
