# Online Shopping WebApp
A microservices based Spring Boot Rest API with data persistence.
# Endpoints
The API has following endpoints :


`/addproduct`
`/findproduct`
`/allproduct`
`/viewproduct`
`/products`
`/delproducts`



`/addcustomer`
`/findcustomer`
`/allcustomer`
`/viewcustomer`
`/customers`
`/delcustomers`

