package com.example.accessingdatamysql.customer;

import org.springframework.data.repository.CrudRepository;


public interface customerRepository extends CrudRepository<customer, Integer> {
}