package cloth_store.onlineshopping.service;

import cloth_store.onlineshopping.model.User;

public interface UserService {

    boolean saveUser(User user);

    User findUserByEmail(String email);

}
