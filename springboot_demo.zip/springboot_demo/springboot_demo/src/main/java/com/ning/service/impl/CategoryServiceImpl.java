package com.ning.service.impl;

import com.ning.entity.Category;
import com.ning.mapper.CategoryMapper;
import com.ning.service.ICategoryService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service

public class CategoryServiceImpl implements ICategoryService {

    /*定义mapper对象，完成数据库访问操作*/
    @Resource
    private com.ning.mapper.CategoryMapper categoryMapper;

    @Override
    public List<Category> list() {
        return categoryMapper.findAll();
    }

    @Override
    public int insert(Category category) {
        return categoryMapper.doAdd(category);
    }

    @Override
    public Category find(Integer category) {
        return categoryMapper.find(category);
    }

    @Override
    public int update(Category category) {
        return categoryMapper.doUpdate(category);
    }
}
