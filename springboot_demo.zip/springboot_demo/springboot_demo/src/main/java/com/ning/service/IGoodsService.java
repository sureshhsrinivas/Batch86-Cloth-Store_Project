package com.ning.service;

import com.ning.entity.Goods;

import java.util.List;

public interface IGoodsService {

    List<Goods> list();

    List<Goods> findRandLimit(Integer size);

    List<Goods> findByCategory(Integer categoryId);

    Goods find(Integer goodsId);

    int insert(Goods goods);

    int update(Goods goods);
}
