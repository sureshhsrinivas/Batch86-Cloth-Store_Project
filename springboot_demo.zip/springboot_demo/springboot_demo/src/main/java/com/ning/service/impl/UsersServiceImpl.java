package com.ning.service.impl;

import com.ning.entity.Users;
import com.ning.mapper.UsersMapper;
import com.ning.service.IUsersService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


@Service
public class UsersServiceImpl implements IUsersService {

    /*定义mapper数据库访问对象*/
    @Resource
    private UsersMapper usersMapper;


    @Override
    public Users adminLogin(Users users) {
        return usersMapper.find(users);
    }
}
