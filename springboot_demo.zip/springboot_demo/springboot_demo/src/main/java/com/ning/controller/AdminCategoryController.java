package com.ning.controller;

import com.ning.entity.Category;
import com.ning.service.ICategoryService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.List;


@RequestMapping("/admin/category")
@Controller
public class AdminCategoryController {

    /*定义业务层对象*/
    @Resource
    private ICategoryService categoryService;

    /*查询*/
    @RequestMapping("/list")
    public String list(Model model)
    {
        List<Category> categoryList = categoryService.list();
        model.addAttribute("categoryList",categoryList);
        return "/admin/category_list";
    }

    /*添加*/
    @RequestMapping("/add_show")
    public String add_show()
    {
        return "/admin/category_add";
    }


    @RequestMapping("/add_submit")
    public String add_submit(Category category){
        //插入数据
        categoryService.insert(category);

        //重定向到分类查询页面
        return "redirect:/admin/category/list";

    }

    @RequestMapping("/update_show")
    public String update_show(Integer categoryId,Model model){
        //根据编号查询数据
        Category category = categoryService.find(categoryId);
        model.addAttribute("category",category);
        return "/admin/category_update";
    }

    @RequestMapping("/update_submit")
    public String update_submit(Category category){
        categoryService.update(category);

        return "redirect:/admin/category/list";
    }





}
