package com.ning.controller;

/*功能：显示后台登录页面，后台登录请求*/

import com.ning.entity.Users;
import com.ning.service.IUsersService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;


@RequestMapping("/admin")
@Controller

public class AdminLoginController{

    @Resource
    private IUsersService usersService;

    @RequestMapping("login_show")
    public String login_show(){
        return "/admin/login";
    }


    @RequestMapping("/login_submit")
    public String login_submit(Users users, HttpSession session, Model model){
        /*根据用户名和密码进行登录校验*/
        Users u = usersService.adminLogin(users);
        
        if(u==null){
            /*model.addAttribute("err","用户名或密码不正确");*/
            model.addAttribute("err","账号有误");
            return "/admin/login";
        }

        /*将登录的账号对象存入session，用于会话跟踪管理*/
        session.setAttribute("adminUser",u);
        return "/admin/index";

    }
}
