package com.ning.service.impl;

import com.ning.entity.Goods;
import com.ning.mapper.GoodsMapper;
import com.ning.service.IGoodsService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service

public class GoodsServiceImpl implements IGoodsService {

    @Resource
    private GoodsMapper goodsMapper;

    @Override
    public List<Goods> list() {
        return goodsMapper.findAll();
    }

    @Override
    public List<Goods> findRandLimit(Integer size) {
        return goodsMapper.findRandLimit(size);
    }

    @Override
    public List<Goods> findByCategory(Integer categoryId) {
        return goodsMapper.findByCategory(categoryId);
    }

    @Override
    public Goods find(Integer goodsId) {
        return goodsMapper.find(goodsId);
    }


    @Override
    public int insert(Goods goods) {
        return goodsMapper.doAdd(goods);
    }

    @Override
    public int update(Goods goods) {
        return goodsMapper.doUpdate(goods);
    }

}
