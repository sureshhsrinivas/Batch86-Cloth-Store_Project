package com.ning.controller;

import com.ning.entity.Category;
import com.ning.entity.Goods;
import com.ning.service.ICategoryService;
import com.ning.service.IGoodsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller

public class FrontHomeController {

    /*获取所有商品分类*/
    @Resource
    private ICategoryService categoryService;

    /*随机获取8个在首页*/
    @Resource
    private IGoodsService goodsService;

    @RequestMapping("/")

    public String index(Model model)
    {

        List<Category> categoryList = categoryService.list();

        List<Goods> goodsList = goodsService.findRandLimit(8);

        model.addAttribute("categoryList",categoryList);
        model.addAttribute("goodList",goodsList);
        //return "欢迎访问我的项目<br/> <a href='/admin/login_show'>访问后台</a>";

        return "/front/index";
    }


    @RequestMapping("/second")
    public String second(Integer categoryId,Model model)
    {
        List<Category> categoryList = categoryService.list();
        List<Goods> goodsList = goodsService.findByCategory(categoryId);

        model.addAttribute("categoryList",categoryList);
        model.addAttribute("goodList",goodsList);
        model.addAttribute("categoryId",categoryId);


        return "/front/second";
    }

    @RequestMapping("/front_logout")
    public String front_logout(HttpSession session)
    {
        session.invalidate();
        return "/front/customerLogin";
    }

    /**
     * 用户登录成功页面
     */

    public String index002(Model model){
        List<Goods>goodsList=goodsService.findRandLimit(8);
        model.addAttribute("goodsList",goodsList);
        return "/front/customerLogin";
    }

}
