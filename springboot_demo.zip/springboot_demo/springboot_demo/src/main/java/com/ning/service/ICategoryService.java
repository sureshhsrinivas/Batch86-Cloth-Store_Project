package com.ning.service;

import com.ning.entity.Category;

import java.util.List;

public interface ICategoryService {

    /*查询所有分类*/
    List<Category> list();

    /*插入数据*/
    int insert(Category category);

    //按编号查询分类
    Category find(Integer category);

    //修改数据
    int update(Category category);

}
