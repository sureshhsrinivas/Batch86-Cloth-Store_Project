package com.ning.controller;

import com.ning.entity.Orders;
import com.ning.service.IOrdersService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.List;

@RequestMapping("/admin/orders")
@Controller
public class AdminOrdersController {
    @Resource
    private IOrdersService ordersService;

    /**
     * 查看所有订单
     */

    @RequestMapping("/Orderslist")
    public String Orderslist(Model model){
        List<Orders> ordersList=ordersService.findAll();
        model.addAttribute("ordersList",ordersList);
        return "/admin/orders_list";
    }

    /**
     * 查看指定账户订单


    @RequestMapping("/findAllByCustomername")
    public String findAllByCustomername(String CustomerUsername,Model model){
         List<Orders> ordersList=ordersService.findAllByCustomername(CustomerUsername);
         model.addAttribute("ordersList",ordersList);
         return "/admin/customer_orders";
    }*/


}
