package com.ning.controller;

import com.ning.entity.Category;
import com.ning.entity.Goods;
import com.ning.service.ICategoryService;
import com.ning.service.IGoodsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@RequestMapping("/admin/goods")
@Controller

public class AdminGoodsController {

    @Resource
    private ICategoryService categoryService;

    @Resource
    private IGoodsService goodsService;

    @RequestMapping("/list")
    public String list(Model model){

        List<Goods> goodsList = goodsService.list();
        model.addAttribute("goodsList",goodsList);
        return "/admin/goods_list";
    }

    @RequestMapping("/add_show")
    public String add_show(Model model){

        List<Category> categoryList = categoryService.list();
        model.addAttribute("categoryList",categoryList);
        return "/admin/goods_add";

    }


    @RequestMapping("/add_submit")
    public String add_submit(Goods goods, MultipartFile file){

        String imgFile = null;
        //判断客户端是否上传了图片
        if(file.isEmpty())
        {
            //如果未上传，使用默认图片
            imgFile="/img/head.jpg";

        }
        else
        {
            //生成新的文件名
            String newFile = UUID.randomUUID() + "-" +file.getOriginalFilename();
            //使用新的文件名构建文件对象
            File f = new File("e:/proj_img",newFile);

            //判断上级目录是否存在，不存在需创建
            if(f.getParentFile().exists())
            {
                f.mkdir();
            }

            try {
                //将上传文件保存到指定磁盘位置
                file.transferTo(f);
                //记录上传文件的web访问路径
                imgFile="/upfile/" + newFile;
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        //设置值goods对象图片路径
        goods.setPicture(imgFile);
        //保存goods对象到数据库
        goodsService.insert(goods);

        //跳转至商品查询页面
        return "redirect:/admin/goods/list";

    }


    /*修改商品信息*/
    @RequestMapping("/update_show")
    public String update_show(Integer goodsId,Model model)
    {
        /*根据编号获取商品信息*/
        Goods goods = goodsService.find(goodsId);
        /*查询分类信息*/
        List<Category> categoryList = categoryService.list();

        model.addAttribute("goods",goods);
        model.addAttribute("categoryList",categoryList);

        return "/admin/goods_update";
    }



    /*提交时修改信息*/
    @RequestMapping("/update_submit")
    public String update_submit(Goods goods, MultipartFile file){

        String imgFile = null;
        //判断客户端是否上传了图片

        if(!file.isEmpty())
        {
            //生成新的文件名
            String newFile = UUID.randomUUID() + "-" +file.getOriginalFilename();
            //使用新的文件名构建文件对象
            File f = new File("e:/proj_img",newFile);

            //判断上级目录是否存在，不存在需创建
            if(!f.getParentFile().exists())
            {
                f.mkdir();
            }

            try {
                //将上传文件保存到指定磁盘位置
                file.transferTo(f);
                goods.setPicture("/updile/"+newFile);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        //保存goods对象到数据库
        goodsService.update(goods);
        //跳转至商品查询页面
        return "redirect:/admin/goods/list";

    }


}
