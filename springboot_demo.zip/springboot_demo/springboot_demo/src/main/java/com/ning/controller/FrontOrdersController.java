package com.ning.controller;

import com.ning.entity.Customer;
import com.ning.entity.Goods;
import com.ning.entity.Orders;
import com.ning.service.ICustomerService;
import com.ning.service.IGoodsService;
import com.ning.service.IOrdersService;
import com.ning.service.IUsersService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/front/orders")
public class FrontOrdersController {

    @Resource
    private IUsersService usersService;
    @Resource
    private ICustomerService customerService;
    @Resource
    private IGoodsService goodsService;
    @Resource
    private IOrdersService ordersService;



    @RequestMapping("/add_show")
    public String add_show(){
        return "/front/add_show";
    }

    /** 用户提交订单**/
    @RequestMapping("add_submit")
    public String add_submit(Orders orders, Model model ){
        ordersService.insert(orders);
        return "redirect:/front/goods/tuijian";
    }

    /**
     * 订单页面确认信息
     */

    @RequestMapping("/order_list")
    public  String order_list(Integer goodsId, Integer customerId, Model model, HttpServletRequest request, HttpSession session){
        Goods goodsList=goodsService.find(goodsId);
        Goods goods =goodsService.find(goodsId);
        //获取系统当前时间
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        String s = simpleDateFormat.format(date);

        Object Id= session.getAttribute("frontCustomer.getCustomerId()");
        Customer customer=customerService.frontfind((Integer) Id);
        model.addAttribute("goodsList",goodsList);
        model.addAttribute("goods",goods);
        model.addAttribute("customer",customer);
        model.addAttribute("s",s);
        return "/front/orders";
    }


   /* @RequestMapping("/order_show")
    public String order_show(Model model,String customerUsername){
        List<Orders> ordersList=ordersService.allorder(customerUsername);
        model.addAttribute("ordersList",ordersList);
        return "/front/order_show";
    }*/

    @RequestMapping("/order_pay")
    public String order_pay(){
        return "/front/order_pay";
    }


}
