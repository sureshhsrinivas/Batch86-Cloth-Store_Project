package com.ning.controller;


import com.ning.entity.Customer;
import com.ning.entity.Orders;
import com.ning.service.ICustomerService;
import com.ning.service.IOrdersService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import java.util.List;


@Controller
@RequestMapping("/front")
public class FrontLoginController {

    /*前台业务对象*/
    @Resource
    private ICustomerService customerService;

    @RequestMapping("/customerLogin_show")
    public String customerLogin_show(){
        return "/front/customerLogin";

    }


    @RequestMapping("/customerLogin_submit")
    public String customerLogin_submit(Customer customer, HttpSession session, Model model){
        /*定义容器对象，账号密码错误时，返回信息*/

        /*账号校验*/
        Customer c = customerService.customerLogin(customer);

        if(c==null){
            /*model.addAttribute("err","用户名或密码不正确");*/
            model.addAttribute("err","账号有误");
            return "/front/customerLogin";
        }

        /*将登录的账号对象存入session，用于会话跟踪管理*/
        session.setAttribute("customerUser",c);
        return "front/index002";


    }

    @RequestMapping("/customerLogout")
    public String logout(HttpSession session)
    {
        session.invalidate();
        return "/front/index";
    }



    /*显示订单信息*/
    @Resource
    private IOrdersService ordersService;
    @RequestMapping("/order_show")
    public String  order_show(Model model,String customerUsername){
        List<Orders> ordersList=ordersService.allorder(customerUsername);
        model.addAttribute("ordersList",ordersList);
        return "/front/order_show";
    }
}
