package com.ning.controller;


import com.ning.entity.Customer;
import com.ning.service.ICustomerService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/front")
public class FrontregisterController {

    @Resource
    private ICustomerService customerService;


    @RequestMapping("/register_submit")
    public String register_submit(String customerUsername, Customer customer , HttpSession session, Model model, HttpServletRequest request)
    {
        int username=request.getParameter("CustomerUsername").length();
        String userpwd=request.getParameter("CustomerPwd");
        String cuserpwd=request.getParameter("CcustomerPwd");
        int phone=request.getParameter("CustomerPhone").length();

        //判断账号密码长度是否正确
        if(username<4||username>20||userpwd.length()>20||userpwd.length()<4){
            model.addAttribute("err","账号密码长度必须大于4个并且小于20个字符！");
            return "/front/register";
        }

        //判断两次密码输入是否一致
        if(userpwd.equals(cuserpwd)!=true){
            model.addAttribute("err","两次密码输入不一致！");
            return "/front/register";
        }
        //判断手机号长度是否正确
        if(phone!=11){
            model.addAttribute("err","手机长度错误！");
            return "/front/register";
        }

        customerService.frontregister(customer);
        return "redirect:/front/customerLogin_show";


    }

    /**
     * 注册页面
     */
    @RequestMapping("/register_show")
    public String register_show(){
        return "/front/register";
    }
}
