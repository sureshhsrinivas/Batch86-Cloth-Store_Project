package com.ning.mapper;

import com.ning.entity.Customer;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CustomerMapper {

    //根据用户名和密码查询
    Customer customerFind(Customer customer);

    //用户注册
    int register (Customer customer);

    /*根据Id找人
     **/
    Customer find_one(Integer customerId);
}
