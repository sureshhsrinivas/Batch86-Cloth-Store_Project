package com.ning.service;

import com.ning.entity.Orders;

import java.util.List;

public interface IOrdersService {

    //查看所有订单
    List<Orders> findAll();
    //查看用户订单
    List<Orders> findAllByCustomername(String CustomerUsername);

    //用户订单添加
    int insert(Orders orders);

    //用户订单查询
    List<Orders> allorder(String CustomerUsername);
}
