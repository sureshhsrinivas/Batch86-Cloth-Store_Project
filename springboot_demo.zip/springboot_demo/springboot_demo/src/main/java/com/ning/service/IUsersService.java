package com.ning.service;


import com.ning.entity.Users;

public interface IUsersService {
    /*后台登录*/
    Users adminLogin(Users users);

}
