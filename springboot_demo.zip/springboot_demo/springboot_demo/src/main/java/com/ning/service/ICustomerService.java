package com.ning.service;

import com.ning.entity.Customer;

public interface ICustomerService {

    //普通用户登录
    Customer customerLogin(Customer customer);

    //普通用户注册
    int frontregister(Customer customer);

    /*根据Id找人*/
    Customer frontfind(Integer customerId);
}
