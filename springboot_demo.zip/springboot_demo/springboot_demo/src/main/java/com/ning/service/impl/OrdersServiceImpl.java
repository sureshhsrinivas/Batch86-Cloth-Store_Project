package com.ning.service.impl;

import com.ning.entity.Orders;
import com.ning.mapper.OrdersMapper;
import com.ning.service.IOrdersService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class OrdersServiceImpl implements IOrdersService {


    @Resource
    private OrdersMapper ordersMapper;

    @Override
    public List<Orders> findAll() {
        return ordersMapper.findAll();
    }

    @Override
    public List<Orders> findAllByCustomername(String CustomerUsername) {
        return ordersMapper.findAllByCustomername(CustomerUsername);
    }


    @Override
    public int insert(Orders orders) {
        return ordersMapper.orderAdd(orders);
    }

    @Override
    public List<Orders> allorder(String customerUsername) {
        return ordersMapper.all_order(customerUsername);
    }


}
