package com.ning.mapper;

import com.ning.entity.Users;
import org.apache.ibatis.annotations.Mapper;

@Mapper

public interface UsersMapper {

    /*根据用户名和密码查询用户*/
    Users find(Users users);




    }
