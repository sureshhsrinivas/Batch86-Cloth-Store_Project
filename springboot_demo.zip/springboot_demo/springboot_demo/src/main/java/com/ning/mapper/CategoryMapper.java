package com.ning.mapper;

import com.ning.entity.Category;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CategoryMapper {

    /*查询所有方法*/

    List<Category> findAll();

    //添加商品分类数据
    int doAdd(Category category);

    /*修改商品分类信息*/
    int doUpdate(Category category);

    //根据编号查询数据
    Category find(Integer categoryId);

}
