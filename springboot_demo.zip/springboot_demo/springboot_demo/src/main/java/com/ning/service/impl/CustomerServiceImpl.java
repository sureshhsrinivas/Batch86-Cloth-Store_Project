package com.ning.service.impl;

import com.ning.entity.Customer;
import com.ning.mapper.CustomerMapper;
import com.ning.service.ICustomerService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class CustomerServiceImpl implements ICustomerService {

    @Resource
    private CustomerMapper customerMapper;

    @Override
    public Customer customerLogin(Customer customer) {
        return customerMapper.customerFind(customer);
    }

    @Override
    public int frontregister(Customer customer) {
        return customerMapper.register(customer);
    }

    @Override
    public Customer frontfind(Integer customerId) {
        return customerMapper.find_one(customerId);
    }

    /*@Override
    public int register(Customer customer) {
        return customerMapper.frontregister(customer);
    }*/
}
