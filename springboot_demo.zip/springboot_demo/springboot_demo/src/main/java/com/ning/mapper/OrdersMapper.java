package com.ning.mapper;

import com.ning.entity.Orders;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface OrdersMapper {

    /*查看所有订单*/
    List<Orders> findAll();

    /*查看指定用户订单*/
    List<Orders> findAllByCustomername(String customerUsername);

    /*用户订单显示*/
    List<Orders> all_order(String customerUsername);

    //用户订单增加
    int orderAdd(Orders orders);
}
