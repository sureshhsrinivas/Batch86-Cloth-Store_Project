package com.ning.mapper;

import com.ning.entity.Goods;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface GoodsMapper {


    /*查询所有*/
    List<Goods>  findAll();

    /*添加商品*/
    int doAdd(Goods goods);

    /*根据编号查询商品*/
    Goods find(Integer goodsId);

   /*更新商品*/
    int doUpdate(Goods goods);

    /*随机获取若干商品*/
    List<Goods> findRandLimit(Integer size);

    /*根据分类查询商品*/
    List<Goods> findByCategory(Integer categoryId);
}
