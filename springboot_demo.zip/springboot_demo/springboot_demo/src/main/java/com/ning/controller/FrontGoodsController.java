package com.ning.controller;

import com.ning.entity.Goods;
import com.ning.service.IGoodsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("/front/goods")
public class FrontGoodsController {
    @Resource
    private IGoodsService goodsService;
    private Integer categoryId;

    /**
     * 前台商品推荐页面

     */
    @RequestMapping("/tuijian")
    public String tuijian(Model model){
        List<Goods> goodsList=goodsService.findRandLimit(8);
        model.addAttribute("goodsList",goodsList);
        return "/front/tuijian";
    }

    /*
    * 分类显示

    * */
    @RequestMapping("/riyongpin")
    public String riyongpin(Model model){
        List <Goods> goodsList=goodsService.findByCategory(3);
        model.addAttribute("goodsList",goodsList);
        return "/front/riyongpin";
    }
    @RequestMapping("/yinpin")
    public String yinpin(Model model){
        List <Goods> goodsList=goodsService.findByCategory(1);
        model.addAttribute("goodsList",goodsList);
        return "/front/yinpin";
    }
    @RequestMapping("/chufang")
    public String chufang(Model model){
        List <Goods> goodsList=goodsService.findByCategory(4);
        model.addAttribute("goodsList",goodsList);
        return "/front/chufang";
    }
    @RequestMapping("/shipin")
    public String shipin(Model model){
        List <Goods> goodsList=goodsService.findByCategory(2);
        model.addAttribute("goodsList",goodsList);
        return "/front/shipin";
    }

    @RequestMapping("/guoshu")
    public String guoshu(Model model){
        /*String GoodsType="果蔬";*/
        List <Goods> goodsList=goodsService.findByCategory(categoryId);
        model.addAttribute("goodsList",goodsList);
        return "/front/guoshu";
    }

}
