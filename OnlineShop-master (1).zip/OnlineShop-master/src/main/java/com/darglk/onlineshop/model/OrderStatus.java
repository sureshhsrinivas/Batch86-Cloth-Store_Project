package com.darglk.onlineshop.model;

public enum OrderStatus {
	BEGIN, PENDING, FINISHED
}
