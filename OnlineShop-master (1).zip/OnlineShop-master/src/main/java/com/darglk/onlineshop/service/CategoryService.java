package com.darglk.onlineshop.service;

import java.util.List;

import com.darglk.onlineshop.model.Category;

public interface CategoryService {

	List<Category> getCategories();

}
