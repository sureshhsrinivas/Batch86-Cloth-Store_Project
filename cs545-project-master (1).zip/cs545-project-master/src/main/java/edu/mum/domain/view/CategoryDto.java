package edu.mum.domain.view;

import lombok.Data;

@Data
public class CategoryDto {
}
