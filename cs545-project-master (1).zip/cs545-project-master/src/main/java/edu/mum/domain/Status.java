package edu.mum.domain;

public enum Status {
    PENDING,
    APPROVED,
    REJECTED
}
