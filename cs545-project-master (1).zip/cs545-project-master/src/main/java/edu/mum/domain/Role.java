package edu.mum.domain;

public enum Role {
    ADMIN, SELLER, BUYER
}
