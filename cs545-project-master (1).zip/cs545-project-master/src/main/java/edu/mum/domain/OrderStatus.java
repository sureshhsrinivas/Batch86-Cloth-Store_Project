package edu.mum.domain;

public enum  OrderStatus {
    NEW, PROCESSING, COMPLETED, CANCELED
}
