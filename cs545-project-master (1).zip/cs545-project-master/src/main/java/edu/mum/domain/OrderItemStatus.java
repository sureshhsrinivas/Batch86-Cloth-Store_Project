package edu.mum.domain;

public enum OrderItemStatus {
    ORDERED, SHIPPED, DELIVERED, CANCELED, RETURNED
}
