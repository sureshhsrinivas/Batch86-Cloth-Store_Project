package edu.mum.exception;

//@Con/trollerAdvice
public class GlobalExceptionHandler {

//    @ExceptionHandler({Exception.class})
//    public ModelAndView displayErrorFancyPage(HttpServletRequest request, Exception ex) {
//        ModelAndView modelAndView = new ModelAndView();
//        modelAndView.addObject("exception", ex);
//        modelAndView.addObject("url", request.getRequestURL());
//        modelAndView.setViewName("error");
//        return modelAndView;
//    }
}
