package edu.mum.onlineshoping.repository;

import org.springframework.data.repository.CrudRepository;

import edu.mum.onlineshoping.model.MyTax;

public interface MyTaxRepository extends CrudRepository<MyTax, Long>{

}
