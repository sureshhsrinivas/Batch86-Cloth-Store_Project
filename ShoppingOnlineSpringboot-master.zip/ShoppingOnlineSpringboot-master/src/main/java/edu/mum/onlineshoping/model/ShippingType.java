package edu.mum.onlineshoping.model;

public enum ShippingType {
	BYBUS, BYSHIP, BYAIR
}
