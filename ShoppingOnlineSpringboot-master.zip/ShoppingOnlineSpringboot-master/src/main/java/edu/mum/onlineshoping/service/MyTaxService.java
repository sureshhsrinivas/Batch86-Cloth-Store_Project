package edu.mum.onlineshoping.service;

import edu.mum.onlineshoping.model.MyTax;

public interface MyTaxService {

	public void addMyTax(MyTax myTax);
}
