package edu.mum.onlineshoping.model;

public enum Role {
  ROLE_ADMIN, ROLE_USER, ROLE_VENDOR;
}
