package edu.mum.onlineshoping.service;

import edu.mum.onlineshoping.model.MyCompany;

public interface MyCompanyService {

	public void addMyCompany(MyCompany myCompany);
}
