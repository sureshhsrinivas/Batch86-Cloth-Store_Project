package edu.mum.onlineshoping.repository;

import org.springframework.data.repository.CrudRepository;

import edu.mum.onlineshoping.model.MyCompany;

public interface MyCompanyRepository extends CrudRepository<MyCompany, Long>{

	
}
