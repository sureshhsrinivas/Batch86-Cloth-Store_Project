# springboot-mysql-webapp
This is a online shopping website built by springboot + mySQL.
